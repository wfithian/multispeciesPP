print.summary.multispeciesPP <-
function(x,...) {
    printCoefmat(x$coef.table)
}
